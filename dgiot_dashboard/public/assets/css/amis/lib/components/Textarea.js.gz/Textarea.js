"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_textarea_autosize_1 = (0, tslib_1.__importDefault)(require("react-textarea-autosize"));
exports.default = react_textarea_autosize_1.default;
//# sourceMappingURL=./components/Textarea.js.map
