self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1b11bb67d9ac7a031cedad40cd9c5b11",
    "url": "assets/images/Device/1.png"
  },
  {
    "revision": "ae36fcd8f9f3a809b7d9d53f29d3330b",
    "url": "assets/images/Device/2.png"
  },
  {
    "revision": "245a6e5837d8371dc0e2075db4698410",
    "url": "assets/images/iconfont/iconfont.css"
  },
  {
    "revision": "d15437e5c4dd6adc9a4d4a537f664080",
    "url": "assets/images/iconfont/iconfont.css.gz"
  },
  {
    "revision": "45ac49dcf38664cee83e5a5a1dc880bc",
    "url": "assets/images/iconfont/iconfont.js"
  },
  {
    "revision": "5ba3433c9e3bbecf61a447795fe1c059",
    "url": "assets/images/iconfont/iconfont.js.gz"
  },
  {
    "revision": "c945c2887cf13438d78ba523f284af27",
    "url": "assets/images/iconfont/iconfont.json"
  },
  {
    "revision": "7e5386c8a69b4086a5f2630bcb67a320",
    "url": "assets/images/iconfont/iconfont.json.gz"
  },
  {
    "revision": "be3114ecaa1d00e5d979128112439e28",
    "url": "assets/images/iconfont/iconfont.ttf"
  },
  {
    "revision": "1eec5f2732a6697577ac2e704619f151",
    "url": "assets/images/iconfont/iconfont.ttf.gz"
  },
  {
    "revision": "ca5f89bcf7e3c848a612f3b9be5e8fe6",
    "url": "assets/images/iconfont/iconfont.woff"
  },
  {
    "revision": "1d4e9e3b956e44291405dca6efc850c2",
    "url": "assets/images/iconfont/iconfont.woff.gz"
  },
  {
    "revision": "79192523e67baa3c434335698c522a74",
    "url": "assets/images/iconfont/iconfont.woff2"
  },
  {
    "revision": "0d5bf62290d304b118bf3acfc2dbcde6",
    "url": "assets/images/iconfont/iconfont.woff2.gz"
  },
  {
    "revision": "6716275524b82f48d3e8aedca9a154e1",
    "url": "assets/images/logo/logo.png"
  },
  {
    "revision": "e9d4d5b4b2204a6ebba2773a1aa721d3",
    "url": "assets/images/platform/assets/empty_images/data_empty.png"
  },
  {
    "revision": "0c7b2e18c5adcf63062fe697f63470a8",
    "url": "assets/images/platform/assets/error_images/403.png"
  },
  {
    "revision": "e51b09c377bad5604e25250ddf252f84",
    "url": "assets/images/platform/assets/error_images/404.png"
  },
  {
    "revision": "2c0cc062dd1730e192a44e6f9ace3385",
    "url": "assets/images/platform/assets/error_images/cloud.png"
  },
  {
    "revision": "8fed5e23ee3b4dba23710659591840de",
    "url": "assets/images/platform/assets/login_images/background.jpg"
  },
  {
    "revision": "73cf0c113996dd5819f986b4e2630289",
    "url": "assets/images/platform/assets/login_images/login_form.png"
  },
  {
    "revision": "5a80ef3753df9a3dd11308dba937f2e3",
    "url": "assets/images/platform/assets/login_images/stretch.png"
  },
  {
    "revision": "bc451283ae6785716a79f5275b8543d5",
    "url": "assets/images/topo/bg/boiler.jpg"
  },
  {
    "revision": "756a9c369ecaa4402102483ef224f60f",
    "url": "bip.json"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "dist/element-icons.ttf"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "dist/element-icons.woff"
  },
  {
    "revision": "a17b6045fb89ca0213db660e8a162ab1",
    "url": "index.html"
  },
  {
    "revision": "581458656971ff0664a7c8122dd4e186",
    "url": "manifest.json"
  },
  {
    "revision": "3a7aec1112d6ca8962f67c81a05352b4",
    "url": "manifest.webmanifest"
  },
  {
    "revision": "c58fbc027ddb49a56fe9e368b9459a9d",
    "url": "netlify.toml"
  },
  {
    "revision": "08c54b2dbea3e7de19ed",
    "url": "output/assets/css/app.dgiot.css?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "e822aa537b39505c2734",
    "url": "output/assets/css/chunk-16b4b6b4.dgiot.css?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "884132b32a26a181fff9",
    "url": "output/assets/css/chunk-2c07e2da.dgiot.css?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "df5ed96f3aec471eac5b",
    "url": "output/assets/css/chunk-dcb897ae.dgiot.css?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "7fda22ca060b514f6edf",
    "url": "output/assets/css/chunk-vendors.dgiot.css?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "08c54b2dbea3e7de19ed",
    "url": "output/assets/js/app.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "ca6a8a620a029c99fdfa",
    "url": "output/assets/js/chunk-0c149e9e.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "e822aa537b39505c2734",
    "url": "output/assets/js/chunk-16b4b6b4.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "fbe4f46d00f7f4c52efd",
    "url": "output/assets/js/chunk-274ba0bd.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "884132b32a26a181fff9",
    "url": "output/assets/js/chunk-2c07e2da.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "890c6dcc2bc2779a6230",
    "url": "output/assets/js/chunk-2d0b9559.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "a820d07e8378d00be348",
    "url": "output/assets/js/chunk-2d0d3a95.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "f8ae32899630d934e90b",
    "url": "output/assets/js/chunk-2d0d7d97.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "afad8c2f960c778f8d57",
    "url": "output/assets/js/chunk-2d0da733.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "242d29615e2479308bf9",
    "url": "output/assets/js/chunk-2d0e6705.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "964155e43994aa4ed230",
    "url": "output/assets/js/chunk-2d0e9b34.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "b300f051cfe772fbe784",
    "url": "output/assets/js/chunk-2d225846.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "814ee7f81a84f5d0d785",
    "url": "output/assets/js/chunk-333cd59e.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "62d6489aa3de4f457954",
    "url": "output/assets/js/chunk-663b4f1b.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "df5ed96f3aec471eac5b",
    "url": "output/assets/js/chunk-dcb897ae.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "7fda22ca060b514f6edf",
    "url": "output/assets/js/chunk-vendors.dgiot.js?v=4.4.7&t=2022-01-20-16:41:20"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "robots.txt"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "static/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "static/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "1a575a4138e5f366474f0e7c5bd614a5",
    "url": "static/fonts/fa-brands-400.1a575a41.woff"
  },
  {
    "revision": "513aa607d398efaccc559916c3431403",
    "url": "static/fonts/fa-brands-400.513aa607.ttf"
  },
  {
    "revision": "592643a83b8541edc52063d84c468700",
    "url": "static/fonts/fa-brands-400.592643a8.eot"
  },
  {
    "revision": "ed311c7a0ade9a75bb3ebf5a7670f31d",
    "url": "static/fonts/fa-brands-400.ed311c7a.woff2"
  },
  {
    "revision": "766913e6c0088ab8c9f73e18b4127bc4",
    "url": "static/fonts/fa-regular-400.766913e6.ttf"
  },
  {
    "revision": "b0e2db3b634d1bc3928e127458d993d8",
    "url": "static/fonts/fa-regular-400.b0e2db3b.eot"
  },
  {
    "revision": "b91d376b8d7646d671cd820950d5f7f1",
    "url": "static/fonts/fa-regular-400.b91d376b.woff2"
  },
  {
    "revision": "d1d7e3b4c219fde0f7376c6facfd7149",
    "url": "static/fonts/fa-regular-400.d1d7e3b4.woff"
  },
  {
    "revision": "0c6bfc668a72935760178f91327aed3a",
    "url": "static/fonts/fa-solid-900.0c6bfc66.eot"
  },
  {
    "revision": "b9625119ce4300f0ef890a8f3234c773",
    "url": "static/fonts/fa-solid-900.b9625119.ttf"
  },
  {
    "revision": "d745348d289b149026921f197929a893",
    "url": "static/fonts/fa-solid-900.d745348d.woff"
  },
  {
    "revision": "d824df7eb2e268626a2dd9a6a741ac4e",
    "url": "static/fonts/fa-solid-900.d824df7e.woff2"
  },
  {
    "revision": "31d28485e1cf7369272270fd730327c0",
    "url": "static/fonts/remixicon.31d28485.31d28485.eot"
  },
  {
    "revision": "881fbc46361e0c0e5f003c159b2f3005",
    "url": "static/fonts/remixicon.881fbc46.881fbc46.woff"
  },
  {
    "revision": "888e61f04316f10bddfff7bee10c6dd0",
    "url": "static/fonts/remixicon.888e61f0.888e61f0.ttf"
  },
  {
    "revision": "9915fef980fa539085da55b84dfde760",
    "url": "static/fonts/remixicon.9915fef9.9915fef9.woff2"
  },
  {
    "revision": "0c7b2e18c5adcf63062fe697f63470a8",
    "url": "static/img/403.0c7b2e18.png"
  },
  {
    "revision": "e51b09c377bad5604e25250ddf252f84",
    "url": "static/img/404.e51b09c3.png"
  },
  {
    "revision": "f3ea5f17f4ee3c0dbcfbb708d82d5bfd",
    "url": "static/img/archive_black_24dp.f3ea5f17.svg"
  },
  {
    "revision": "8fed5e23ee3b4dba23710659591840de",
    "url": "static/img/background.8fed5e23.jpg"
  },
  {
    "revision": "110420cf1d57846d6bc81289c4a84db9",
    "url": "static/img/bg.110420cf.png"
  },
  {
    "revision": "bc451283ae6785716a79f5275b8543d5",
    "url": "static/img/boiler.bc451283.jpg"
  },
  {
    "revision": "e9d4d5b4b2204a6ebba2773a1aa721d3",
    "url": "static/img/data_empty.e9d4d5b4.png"
  },
  {
    "revision": "1d5619cd804367cefe6da2d79289218a",
    "url": "static/img/fa-brands-400.1d5619cd.svg"
  },
  {
    "revision": "c5d109be8edd3de0f60eb472bd9ef691",
    "url": "static/img/fa-regular-400.c5d109be.svg"
  },
  {
    "revision": "37bc7099f6f1ba80236164f22e905837",
    "url": "static/img/fa-solid-900.37bc7099.svg"
  },
  {
    "revision": "143fa2e1aba94a606256121778145ea8",
    "url": "static/img/folder_black_24dp.143fa2e1.svg"
  },
  {
    "revision": "3ef7937ef35ed8bf946e00fecb339579",
    "url": "static/img/icon2.3ef7937e.png"
  },
  {
    "revision": "e19073aeb51f38d860a5c343516f36e9",
    "url": "static/img/icon4.e19073ae.png"
  },
  {
    "revision": "3284fb792dd849a578442fc0abdcc957",
    "url": "static/img/image_black_24dp.3284fb79.svg"
  },
  {
    "revision": "3c9cb9269be11a558c6aec2df95d02ae",
    "url": "static/img/live_tv_black_24dp.3c9cb926.svg"
  },
  {
    "revision": "a490dea5dfaf5030ccadffa8ea04bdf0",
    "url": "static/img/personal_video_black_24dp.a490dea5.svg"
  },
  {
    "revision": "bc9bdb9dd805d21d23421a1043512bbe",
    "url": "static/img/remixicon.95138f36.bc9bdb9d.svg"
  },
  {
    "revision": "15b1384cf31ef362dd4a4c21be242d75",
    "url": "static/img/timeline_black_24dp.15b1384c.svg"
  },
  {
    "revision": "7834d8f55f48992f497dddcd1ec24db4",
    "url": "static/img/videocam_black_24dp.7834d8f5.svg"
  },
  {
    "revision": "8b96109af06caa08de508ff2503cbdd2",
    "url": "static/img/volume_mute_black_24dp.8b96109a.svg"
  },
  {
    "revision": "4835d0b258c85cf23a26e1e28296110c",
    "url": "static/img/volume_up_black_24dp.4835d0b2.svg"
  },
  {
    "revision": "cb2fe1fd3cfdb652b22f3acc177f9f34",
    "url": "stormkit.config.yml"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "undefined"
  },
  {
    "revision": "47865685051f154cd38a65a2d3bc5929",
    "url": "vercel.json"
  }
]);